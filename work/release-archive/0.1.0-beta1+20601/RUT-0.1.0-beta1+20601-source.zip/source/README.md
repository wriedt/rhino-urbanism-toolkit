# Rhino Urbanism Toolkit (RUT)

Utility scripts for architecture and urbanism studios working in Rhino 8.

## Plugin beta preparation

Beta 1 release preparation is recorded in [the phase 6 review](PHASE6_RELEASE_REVIEW.md).
The review kit includes the package, matching source, offline help, install/remove
helpers and checksums. Final acceptance and authorization to share remain pending.

The plugin project now includes the 18 planned beta commands, their light/dark
toolbar icons and an explicit shared-library allowlist. See the
[beta quick start](BETA_QUICK_START.md), [release plan](BETA_RELEASE_PLAN.md) and
[build instructions](packaging/README.md). Rune reports his hands-on tests passed,
including the two conditional tools, which remain in the candidate. Isolated installed-package checks passed;
see [the phase 4 record](PHASE4_VALIDATION.md) for results and limits.
The [phase 5 test sheet](BETA_HANDS_ON_TESTS.md) records the user-reported pass;
the six-station practice drawing remains under `work/phase5-validation/`.
The [phase 3 validation record](PHASE3_VALIDATION.md) documents 1,103 passing
checks, synthetic performance and the remaining installed/manual checks.

## Running the tools

Keep each command with its shared helper modules, including `urbanism_ui.py`.
The recommended installation folder is `C:\Projects\rhino-urbanism-toolkit`.
If you use another folder, adjust the full paths in the command documentation
and your Rhino toolbar buttons or aliases accordingly.

Open `rhino-urbanism-toolkit.rhproj` in Rhino's Script Editor for the project
settings. RUT is the short name used in tool dialogs; individual command and
helper filenames remain stable.

## Tools

- [Layer utilities](LayerTools.md): isolate selected objects' layers and restore
  visibility or locks, show/unlock all layers, and expand/collapse the layer tree.

- [QuickFloorArea](QuickFloorArea.md): print and copy a solid/base area in m²,
  with command-line warnings and coral geometry inspection if measurement fails.
  Run `RUTQuickFloorArea`.
- [FloorArea](FloorArea.md): floating section/base-area inspector that updates
  with selection and geometry edits. Run `RUTFloorArea`.

- [Block commands](BlockCommands.md): six focused commands for creating and
  consolidating versions, renaming families, and assigning, applying, or reviewing
  block home layers. Choices and reviews use the shared aqua dialogs.
  Run `RUTCreateBlockVersion`, `RUTConsolidateBlockVersions`, `RUTRenameBlockFamily`,
  `RUTAssignBlockLayer`, `RUTApplyBlockLayers` and `RUTShowBlockLayers`.

- [Shape Builder](ShapeBuilder.md): merge or erase curve and hatch regions, preserve
  leftover open curves, and inherit the drag-start shape's properties. Run `RUTShapeBuilder`.

- [PushPullCurve](PushPullCurve.md): move or extrude straight sections of planar
  polylines or mixed curves, with exact arc/spline trimming and live preview.
- [Block home layers](BlockLayerAssignment.md): save definition-wide rules and
  review top-level or optional nested movements, skipping linked/reference blocks.
