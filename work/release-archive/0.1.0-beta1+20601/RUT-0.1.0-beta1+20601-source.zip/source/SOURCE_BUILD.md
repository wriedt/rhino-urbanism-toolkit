# Building this source snapshot

Requires Windows, Rhino 8.36 and Python 3. Run packaging/Build.ps1 -PythonExe python from this folder. RhinoCode is supplied by Rhino. Run python packaging/test_packaging.py and packaging/Verify-Build.ps1 to check the build. The build wrapper stages runtime files, builds the plugin and applies the final toolbar. Local source snapshot; uncommitted changes are included. No commit or publication is implied.
