"""Assemble an explicit, local-only review kit from the verified Yak build."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import zipfile

from prepare import DOCS, commands, HELPERS

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT/'build/rh8_36-win'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def helper(action, package_name):
    operation = f'install "%~dp0{package_name}"' if action == 'install' else 'uninstall rhino-urbanism-toolkit'
    return r'''@echo off
setlocal
if not exist "%ProgramFiles%\Rhino 8\System\Yak.exe" (
 echo Rhino 8 was not found in Program Files. See Help\BETA_QUICK_START.md.
 pause
 exit /b 2
)
tasklist /FI "IMAGENAME eq Rhino.exe" /NH 2>nul | findstr /I /C:"Rhino.exe" >nul
if not errorlevel 1 (
 echo Save your drawings and close ALL Rhino windows, then run this helper again.
 pause
 exit /b 3
)
"%ProgramFiles%\Rhino 8\System\Yak.exe" ''' + operation + r'''
if errorlevel 1 (
 echo The operation did not complete. Keep the message above and contact Rune.
 pause
 exit /b 1
)
echo Done. See Help\BETA_QUICK_START.md for the next step.
pause
exit /b 0
'''


def build():
    package = max(BUILD.glob('*-rh8_36-win.yak'), key=lambda p: p.stat().st_mtime_ns)
    with zipfile.ZipFile(package) as z:
        manifest = z.read('manifest.yml').decode('utf-8-sig')
    version = re.search(r'^version:\s*(\S+)', manifest, re.M)[1]
    release = json.loads((ROOT/'packaging/release.json').read_text())
    probe = json.loads((ROOT/'work/phase6-validation/package-probe.json').read_text())
    checks = json.loads((BUILD/'preparation-checks.json').read_text(encoding='utf-8-sig'))
    assert probe['success'] and probe['version'] == version, 'Final installed probe must match this build.'
    assert version.split('+')[0] == release['version']
    assert re.fullmatch(r'[0-9A-Za-z.+-]+', version)
    folder = ROOT/'release'/version
    assert not folder.exists(), 'Release kits are immutable; build a new candidate instead of overwriting one.'
    folder.mkdir(parents=True)
    shutil.copyfile(package, folder/package.name)
    shutil.copyfile(BUILD/'RUT.rui', folder/'RUT.rui')
    shutil.copyfile(ROOT/'LICENSE', folder/'LICENSE')
    help_dir = folder/'Help'
    help_dir.mkdir()
    for name in DOCS:
        shutil.copyfile(ROOT/name, help_dir/name)
    for name, action in [('Install-RUT.cmd', 'install'), ('Remove-RUT.cmd', 'uninstall')]:
        (folder/name).write_bytes(helper(action, package.name).replace('\n', '\r\n').encode('ascii'))
    # Corresponding project sources from this working tree, not an older remote
    # branch. Explicit roots exclude drawings, credentials, caches and work/.
    source_files = {ROOT/e['source'] for e in commands()}
    source_files |= {ROOT/(name+'.py') for name in HELPERS}
    source_files |= {ROOT/'rhino-urbanism-toolkit.rhproj', ROOT/'LICENSE', ROOT/'README.md'}
    source_files |= set(ROOT.glob('*.md')) | set(ROOT.glob('test_*.py'))
    for directory in ('packaging', 'tests', 'assets/toolbar/v1'):
        source_files |= {p for p in (ROOT/directory).rglob('*') if p.is_file()
            and '__pycache__' not in p.parts and p.suffix.lower() in {'.py', '.ps1', '.json', '.md', '.svg', '.png'}}
    source_name = 'RUT-'+version+'-source.zip'
    with zipfile.ZipFile(folder/source_name, 'w', zipfile.ZIP_DEFLATED) as z:
        for path in sorted(source_files):
            relative = path.relative_to(ROOT)
            assert not set(relative.parts) & {'.git', '.codex', 'work', 'build', 'release'}
            z.write(path, 'source/'+relative.as_posix())
        z.writestr('source/SOURCE_BUILD.md', '# Building this source snapshot\n\n'
            'Requires Windows, Rhino 8.36 and Python 3. Run packaging/Build.ps1 '
            '-PythonExe python from this folder. RhinoCode is supplied by Rhino. '
            'Run python packaging/test_packaging.py and packaging/Verify-Build.ps1 '
            'to check the build. The build wrapper stages runtime files, builds '
            'the plugin and applies the final toolbar. Local source snapshot; '
            'uncommitted changes are included. No commit or publication is implied.\n')
    info = {'product': 'Rhino Urbanism Toolkit', 'version': version,
        'status': release['release_status'], 'platform': 'Windows', 'minimum_rhino': '8.36',
        'tested_rhino': '8.36.26296.17001', 'tested_windows_build': '26300.9974',
        'package': package.name, 'package_sha256': digest(package.read_bytes()),
        'source_archive': source_name, 'source_sha256': digest((folder/source_name).read_bytes()),
        'commands': [e['command'] for e in commands()],
        'toolbar': 'One full-name tab; 18 commands; three category separators',
        'known_release_decision': 'Unresolved crash during automated floating-toolbar setup',
        'source_snapshot': 'Local working tree, not a published commit',
        'validation': {'build_content_checks': checks['passed'], 'packaging_tests': 5,
            'automatic_discovery': probe['success'], 'registered_commands': len(probe['commands']),
            'source_access_blocked': probe['source_access_blocked'], 'measurement_m2': probe['measurement'],
            'hands_on': 'Passed, reported by Rune; detailed per-item results not supplied'},
        'published': False, 'sharing_authorized': False}
    (folder/'release-info.json').write_text(json.dumps(info, indent=2)+'\n', encoding='utf-8')
    (folder/'START_HERE.md').write_text('# RUT beta 1 — review kit\n\n'
        '**Prepared for Rune; acceptance and authorization to share are pending.**\n\n'
        f'Exact package version: **{version}**.\n\n'
        '1. Read [release notes](Help/BETA_RELEASE_NOTES.md), especially the known '
        'toolbar setup crash.\n2. Follow the [quick start](Help/BETA_QUICK_START.md) '
        'for install, update and removal.\n3. Use the [feedback form](Help/BETA_FEEDBACK.md) '
        'for problems.\n\nThe kit contains the local Yak package, install/remove '
        'helpers, standalone toolbar, offline help, GPL license and matching project '
        'sources. SHA256SUMS.txt records every kit file. Nothing has been uploaded '
        'or sent to testers.\n', encoding='utf-8')
    sums = {p.relative_to(folder).as_posix(): digest(p.read_bytes())
        for p in sorted(folder.rglob('*')) if p.is_file()}
    (folder/'SHA256SUMS.txt').write_text(''.join(h+'  '+n+'\n' for n,h in sums.items()), encoding='utf-8')
    archive = folder.parent/('RUT-'+version+'-Windows.zip')
    assert not archive.exists()
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
        for path in sorted(folder.rglob('*')):
            if path.is_file():
                z.write(path, folder.name+'/'+path.relative_to(folder).as_posix())
    with zipfile.ZipFile(archive) as z:
        for name, expected in sums.items():
            assert digest(z.read(folder.name+'/'+name)) == expected, name
    report = {'version': version, 'folder': str(folder), 'archive': str(archive),
        'archive_sha256': digest(archive.read_bytes()), 'verified_files': len(sums),
        'source_files': len(source_files), 'approval': 'Pending', 'published': False}
    (ROOT/'build/release-kit.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    build()
